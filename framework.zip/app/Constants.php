<?php
class Constants {

}