<?php
/* Datos de configuracion de la base de datos */
class Database {
   //Configuracion base de datos
   public static $config = array(
      "driver" => "mysql",
      "host" => "localhost",
      "port" => "3306",
      "db" => "framework",
      "user" => "root",
      "pass" => "",
      "charset" => "utf8"
   );
}