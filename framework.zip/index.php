<?php

require 'wwwroot' . DIRECTORY_SEPARATOR . 'index.php';